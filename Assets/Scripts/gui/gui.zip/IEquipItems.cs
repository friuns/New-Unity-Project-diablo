﻿
using UnityEngine;



public class IEquipItems : MonoBehaviour
{
	public int[] itemIDs;

	void Start ()
	{
		if (itemIDs != null && itemIDs.Length > 0)
		{
			IEquipment eq = GetComponent<IEquipment>();
			if (eq == null) eq = gameObject.AddComponent<IEquipment>();

			int qualityLevels = (int)IGameItem.Quality._LastDoNotUse;

			for (int i = 0, imax = itemIDs.Length; i < imax; ++i)
			{
				int index = itemIDs[i];
				IBaseItem item = IDatabase.FindByID(index);

				if (item != null)
				{
					IGameItem gi = new IGameItem(index, item);
					gi.quality = (IGameItem.Quality)Random.Range(0, qualityLevels);
					gi.itemLevel = NGUITools.RandomRange(item.minItemLevel, item.maxItemLevel);
					eq.Equip(gi);
				}
				else
				{
					Debug.LogWarning("Can't resolve the item ID of " + index);
				}
			}
		}
		Destroy(this);
	}
}