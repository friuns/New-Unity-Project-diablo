﻿using UnityEngine;
using System.Collections.Generic;

public class IEquipment : MonoBehaviour
{
    IGameItem[] mItems;
    IAttachmentPoint[] mAttachments;
    public IGameItem[] equippedItems { get { return mItems; } }
    public IGameItem Replace(IBaseItem.Slot slot, IGameItem item)
    {
        IBaseItem baseItem = (item != null) ? item.baseItem : null;
        if (slot != IBaseItem.Slot.None)
        {
            if (baseItem != null && baseItem.slot != slot) return item;
            if (mItems == null)
            {
                int count = (int)IBaseItem.Slot._LastDoNotUse;
                mItems = new IGameItem[count];
            }
            IGameItem prev = mItems[(int)slot - 1];
            mItems[(int)slot - 1] = item;
            if (mAttachments == null) mAttachments = GetComponentsInChildren<IAttachmentPoint>();
            for (int i = 0, imax = mAttachments.Length; i < imax; ++i)
            {
                IAttachmentPoint ip = mAttachments[i];
                if (ip.slot == slot)
                {
                    GameObject go = ip.Attach(baseItem != null ? baseItem.attachment : null);
                    if (baseItem != null && go != null)
                    {
                        Renderer ren = go.renderer;
                        if (ren != null) ren.material.color = baseItem.color;
                    }
                }
            }
            return prev;
        }
        else if (item != null)
        {
            Debug.LogWarning("Can't equip \"" + item.name + "\" because it doesn't specify an item slot");
        }
        return item;
    }
    public IGameItem Equip(IGameItem item)
    {
        if (item != null)
        {
            Debug.Log("Enquiped",gameObject);
            IBaseItem baseItem = item.baseItem;
            if (baseItem != null) return Replace(baseItem.slot, item);
            else Debug.LogWarning("Can't resolve the item ID of " + item.baseItemID);
        }
        return item;
    }
    public IGameItem Unequip(IGameItem item)
    {
        if (item != null)
        {
            IBaseItem baseItem = item.baseItem;
            if (baseItem != null) return Replace(baseItem.slot, null);
        }
        return item;
    }
    public IGameItem Unequip(IBaseItem.Slot slot) { return Replace(slot, null); }
    public bool HasEquipped(IGameItem item)
    {
        if (mItems != null)
        {
            for (int i = 0, imax = mItems.Length; i < imax; ++i)
            {
                if (mItems[i] == item) return true;
            }
        }
        return false;
    }
    public bool HasEquipped(IBaseItem.Slot slot)
    {
        if (mItems != null)
        {
            for (int i = 0, imax = mItems.Length; i < imax; ++i)
            {
                IBaseItem baseItem = mItems[i].baseItem;
                if (baseItem != null && baseItem.slot == slot) return true;
            }
        }
        return false;
    }
    public IGameItem GetItem(IBaseItem.Slot slot)
    {
        if (slot != IBaseItem.Slot.None)
        {
            int index = (int)slot - 1;
            if (mItems != null && index < mItems.Length)
            {
                return mItems[index];
            }
        }
        return null;
    }
}