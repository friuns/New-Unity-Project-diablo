﻿using UnityEngine;
using System.Collections.Generic;
[System.Serializable]
public class IBaseItem
{
    public enum Slot
    {
        None, Weapon, Shield,
        Body,
        Shoulders,
        Bracers,
        Boots,
        Trinket,
        _LastDoNotUse,
    }
    public int id16;
    public string name;
    public string description;
    public Slot slot = Slot.None;
    public int minItemLevel = 1;
    public int maxItemLevel = 50;
    public List<IStat> stats = new List<IStat>();
    public GameObject attachment;
    public Color color = Color.white;
    public UIAtlas iconAtlas;
    public string iconName = "";
}