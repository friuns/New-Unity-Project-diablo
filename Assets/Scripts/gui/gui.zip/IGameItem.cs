using UnityEngine;
using System.Collections.Generic;


[System.Serializable]
public class IGameItem
{
    public enum Quality
    {
        Broken,
        Cursed,
        Damaged,
        Worn,
        Sturdy, Polished,
        Improved,
        Crafted,
        Superior,
        Enchanted,
        Epic,
        Legendary,
        _LastDoNotUse,
    }

    [SerializeField]
    int mBaseItemID = 0;


    public Quality quality = Quality.Sturdy;


    public int itemLevel = 1;

    IBaseItem mBaseItem;


    public int baseItemID { get { return mBaseItemID; } }


    public IBaseItem baseItem
    {
        get
        {
            if (mBaseItem == null)
            {
                mBaseItem = IDatabase.FindByID(baseItemID);
            }
            return mBaseItem;
        }
    }


    public string name
    {
        get
        {
            if (baseItem == null) return null;
            return quality.ToString() + " " + baseItem.name;
        }
    }


    public float statMultiplier
    {
        get
        {
            float mult = 0f;

            switch (quality)
            {
                case Quality.Cursed: mult = -1f; break;
                case Quality.Broken: mult = 0f; break;
                case Quality.Damaged: mult = 0.25f; break;
                case Quality.Worn: mult = 0.9f; break;
                case Quality.Sturdy: mult = 1f; break;
                case Quality.Polished: mult = 1.1f; break;
                case Quality.Improved: mult = 1.25f; break;
                case Quality.Crafted: mult = 1.5f; break;
                case Quality.Superior: mult = 1.75f; break;
                case Quality.Enchanted: mult = 2f; break;
                case Quality.Epic: mult = 2.5f; break;
                case Quality.Legendary: mult = 3f; break;
            }

            float linear = itemLevel / 50f;

            mult *= Mathf.Lerp(linear, linear * linear, 0.5f);
            return mult;
        }
    }


    public Color color
    {
        get
        {
            Color c = Color.white;

            switch (quality)
            {
                case Quality.Cursed: c = Color.red; break;
                case Quality.Broken: c = new Color(0.4f, 0.2f, 0.2f); break;
                case Quality.Damaged: c = new Color(0.4f, 0.4f, 0.4f); break;
                case Quality.Worn: c = new Color(0.7f, 0.7f, 0.7f); break;
                case Quality.Sturdy: c = new Color(1.0f, 1.0f, 1.0f); break;
                case Quality.Polished: c = NGUIMath.HexToColor(0xe0ffbeff); break;
                case Quality.Improved: c = NGUIMath.HexToColor(0x93d749ff); break;
                case Quality.Crafted: c = NGUIMath.HexToColor(0x4eff00ff); break;
                case Quality.Superior: c = NGUIMath.HexToColor(0x00baffff); break;
                case Quality.Enchanted: c = NGUIMath.HexToColor(0x7376fdff); break;
                case Quality.Epic: c = NGUIMath.HexToColor(0x9600ffff); break;
                case Quality.Legendary: c = NGUIMath.HexToColor(0xff9000ff); break;
            }
            return c;
        }
    }


    public IGameItem(int id) { mBaseItemID = id; }


    public IGameItem(int id, IBaseItem bi) { mBaseItemID = id; mBaseItem = bi; }


    public List<IStat> CalculateStats()
    {
        List<IStat> stats = new List<IStat>();

        if (baseItem != null)
        {
            float mult = statMultiplier;
            List<IStat> baseStats = baseItem.stats;

            for (int i = 0, imax = baseStats.Count; i < imax; ++i)
            {
                IStat bs = baseStats[i];
                int amount = Mathf.RoundToInt(mult * bs.amount);
                if (amount == 0) continue;

                bool found = false;

                for (int b = 0, bmax = stats.Count; b < bmax; ++b)
                {
                    IStat s = stats[b];

                    if (s.id == bs.id && s.modifier == bs.modifier)
                    {
                        s.amount += amount;
                        found = true;
                        break;
                    }
                }

                if (!found)
                {
                    IStat stat = new IStat();
                    stat.id = bs.id;
                    stat.amount = amount;
                    stat.modifier = bs.modifier;
                    stats.Add(stat);
                }
            }

            stats.Sort(IStat.CompareArmor);
        }
        return stats;
    }
}