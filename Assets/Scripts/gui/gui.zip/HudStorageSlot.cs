﻿using UnityEngine;














public class HudStorageSlot : HudItemSlot
{
    public HudItemStorage storage;
    public int slot = 0;
    override protected IGameItem observedItem
    {
        get
        {
            return (storage != null) ? storage.GetItem(slot) : null;
        }
    }
    override protected IGameItem Replace(IGameItem item)
    {
        return (storage != null) ? storage.Replace(slot, item) : item;
    }
}