﻿using UnityEngine;
using System.Collections.Generic;
public class HudItemStorage : MonoBehaviour
{
    public int maxItemCount = 8;
    public int maxRows = 4;
    public int maxColumns = 4;
    public GameObject template;
    public UIWidget background;
    public int spacing = 128;
    public int padding = 10;
    List<IGameItem> mItems = new List<IGameItem>();
    public List<IGameItem> items { get { while (mItems.Count < maxItemCount) mItems.Add(null); return mItems; } }
    public IGameItem GetItem(int slot) { return (slot < items.Count) ? mItems[slot] : null; }
    public IGameItem Replace(int slot, IGameItem item)
    {
        if (slot < maxItemCount)
        {
            IGameItem prev = items[slot];
            mItems[slot] = item;
            return prev;
        }
        return item;
    }
    void Start()
    {
        if (template != null)
        {
            int count = 0;
            Bounds b = new Bounds();
            for (int y = 0; y < maxRows; ++y)
            {
                for (int x = 0; x < maxColumns; ++x)
                {
                    GameObject go = NGUITools.AddChild(gameObject, template);
                    Transform t = go.transform;
                    t.localPosition = new Vector3(padding + (x + 0.5f) * spacing, -padding - (y + 0.5f) * spacing, 0f);
                    HudStorageSlot slot = go.GetComponent<HudStorageSlot>();
                    if (slot != null)
                    {
                        slot.storage = this;
                        slot.slot = count;
                    }
                    b.Encapsulate(new Vector3(padding * 2f + (x + 1) * spacing, -padding * 2f - (y + 1) * spacing, 0f));
                    if (++count >= maxItemCount)
                    {
                        if (background != null)
                            background.transform.localScale = b.size;
                        return;
                    }
                }
            }
            if (background != null) background.transform.localScale = b.size;
        }
    }
}