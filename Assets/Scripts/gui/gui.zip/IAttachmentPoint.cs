﻿using UnityEngine;












public class IAttachmentPoint : MonoBehaviour
{
    public IBaseItem.Slot slot;
    GameObject mPrefab;
    GameObject mChild;
    public GameObject Attach(GameObject prefab)
    {
        if (mPrefab != prefab)
        {
            mPrefab = prefab;
            if (mChild != null) Destroy(mChild);
            if (mPrefab != null)
            {
                Transform t = transform;
                mChild = Instantiate(mPrefab, t.position, t.rotation) as GameObject;
                Transform ct = mChild.transform;
                ct.parent = t;
                ct.localPosition = Vector3.zero;
                ct.localRotation = Quaternion.identity;
                ct.localScale = Vector3.one;
            }
        }
        return mChild;
    }
}