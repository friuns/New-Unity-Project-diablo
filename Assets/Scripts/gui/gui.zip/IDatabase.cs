﻿using UnityEngine;
using System.Collections.Generic;
[ExecuteInEditMode]
public class IDatabase : MonoBehaviour
{
    static IDatabase[] mList;
    static bool mIsDirty = true;
    static public IDatabase[] list
    {
        get
        {
            if (mIsDirty)
            {
                mIsDirty = false;
                mList = FindSceneObjectsOfType(typeof(IDatabase)) as IDatabase[];
            }
            return mList;
        }
    }
    public int databaseID = 0;
    public List<IBaseItem> items = new List<IBaseItem>();
    public UIAtlas iconAtlas;
    void OnEnable() { mIsDirty = true; }
    void OnDisable() { mIsDirty = true; }
    IBaseItem GetItem(int id16)
    {
        for (int i = 0, imax = items.Count; i < imax; ++i)
        {
            IBaseItem item = items[i];
            if (item.id16 == id16) return item;
        }
        return null;
    }
    static IDatabase GetDatabase(int dbID)
    {
        for (int i = 0, imax = list.Length; i < imax; ++i)
        {
            IDatabase db = list[i];
            if (db.databaseID == dbID) return db;
        }
        return null;
    }
    static public IBaseItem FindByID(int id32)
    {
        IDatabase db = GetDatabase(id32 >> 16);
        return (db != null) ? db.GetItem(id32 & 0xFFFF) : null;
    }
    static public IBaseItem FindByName(string exact)
    {
        for (int i = 0, imax = list.Length; i < imax; ++i)
        {
            IDatabase db = list[i];
            for (int b = 0, bmax = db.items.Count; b < bmax; ++b)
            {
                IBaseItem item = db.items[b];
                if (item.name == exact)
                {
                    return item;
                }
            }
        }
        return null;
    }
    static public int FindItemID(IBaseItem item)
    {
        for (int i = 0, imax = list.Length; i < imax; ++i)
        {
            IDatabase db = list[i];
            if (db.items.Contains(item))
            {
                return (db.databaseID << 16) | item.id16;
            }
        }
        return -1;
    }
}