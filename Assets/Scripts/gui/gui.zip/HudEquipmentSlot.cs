


using UnityEngine;



public class HudEquipmentSlot : HudItemSlot
{
    public IEquipment equipment;
    public IBaseItem.Slot slot;

    override protected IGameItem observedItem
    {
        get
        {
            return (equipment != null) ? equipment.GetItem(slot) : null;
        }
    }

    override protected IGameItem Replace(IGameItem item)
    {
        return (equipment != null) ? equipment.Replace(slot, item) : item;
    }
}