﻿using UnityEngine;
using System.Collections.Generic;
public abstract class HudItemSlot : MonoBehaviour
{
    public UISprite icon;
    public UIWidget background;
    public UILabel label;
    public AudioClip grabSound;
    public AudioClip placeSound;
    public AudioClip errorSound;
    IGameItem mItem;
    string mText = "";
    static IGameItem mDraggedItem;
    abstract protected IGameItem observedItem { get; }
    abstract protected IGameItem Replace(IGameItem item);
    void OnTooltip(bool show)
    {
        IGameItem item = show ? mItem : null;
        if (item != null)
        {
            IBaseItem bi = item.baseItem;
            if (bi != null)
            {
                string t = "[" + NGUITools.EncodeColor(item.color) + "]" + item.name + "[-]\n";
                t += "[AFAFAF]Level " + item.itemLevel + " " + bi.slot;
                List<IStat> stats = item.CalculateStats();
                for (int i = 0, imax = stats.Count; i < imax; ++i)
                {
                    IStat stat = stats[i];
                    if (stat.amount == 0) continue;
                    if (stat.amount < 0)
                    {
                        t += "\n[FF0000]" + stat.amount;
                    }
                    else
                    {
                        t += "\n[00FF00]+" + stat.amount;
                    }
                    if (stat.modifier == IStat.Modifier.Percent) t += "%";
                    t += " " + stat.id;
                    t += "[-]";
                }
                if (!string.IsNullOrEmpty(bi.description)) t += "\n[FF9900]" + bi.description;
                UITooltip.ShowText(t);
                return;
            }
        }
        UITooltip.ShowText(null);
    }
    void OnClick()
    {
        if (mDraggedItem != null)
        {
            OnDrop(null);
        }
        else if (mItem != null)
        {
            mDraggedItem = Replace(null);
            if (mDraggedItem != null) NGUITools.PlaySound(grabSound);
            UpdateCursor();
        }
    }
    void OnDrag(Vector2 delta)
    {
        if (mDraggedItem == null && mItem != null)
        {
            UICamera.currentTouch.clickNotification = UICamera.ClickNotification.BasedOnDelta;
            mDraggedItem = Replace(null);
            NGUITools.PlaySound(grabSound);
            UpdateCursor();
        }
    }
    void OnDrop(GameObject go)
    {
        IGameItem item = Replace(mDraggedItem);
        if (mDraggedItem == item) NGUITools.PlaySound(errorSound);
        else if (item != null) NGUITools.PlaySound(grabSound);
        else NGUITools.PlaySound(placeSound);
        mDraggedItem = item;
        UpdateCursor();
    }
    void UpdateCursor()
    {
        if (mDraggedItem != null && mDraggedItem.baseItem != null)
        {
            UICursor.Set(mDraggedItem.baseItem.iconAtlas, mDraggedItem.baseItem.iconName);
        }
        else
        {
            UICursor.Clear();
        }
    }
    void Update()
    {
        IGameItem i = observedItem;
        if (mItem != i)
        {
            mItem = i;
            IBaseItem baseItem = (i != null) ? i.baseItem : null;
            if (label != null)
            {
                string itemName = (i != null) ? i.name : null;
                if (string.IsNullOrEmpty(mText)) mText = label.text;
                label.text = (itemName != null) ? itemName : mText;
            }
            if (icon != null)
            {
                if (baseItem == null || baseItem.iconAtlas == null)
                {
                    icon.enabled = false;
                }
                else
                {
                    icon.atlas = baseItem.iconAtlas;
                    icon.spriteName = baseItem.iconName;
                    icon.enabled = true;
                    icon.MakePixelPerfect();
                }
            }
            if (background != null)
            {
                background.color = (i != null) ? i.color : Color.white;
            }
        }
    }
}